#P4LAB1 B - Initials

import turtle


ninja_turtle = turtle.Turtle()

ninja_turtle.color("red")
ninja_turtle.left(90)
ninja_turtle.forward(150)

ninja_turtle.color("blue")

for x in range(7):
    ninja_turtle.right(45)
    ninja_turtle.forward(50)

ninja_turtle.penup()
ninja_turtle.right(135)
ninja_turtle.forward(150)
ninja_turtle.left(90)
ninja_turtle.forward(80)
ninja_turtle.pendown()

ninja_turtle.color("green")
ninja_turtle.right(180)


ninja_turtle.forward(180)
ninja_turtle.right(180)
ninja_turtle.forward(90)
ninja_turtle.right(90)


ninja_turtle.forward(45)
ninja_turtle.color("orange")
ninja_turtle.forward(45)
ninja_turtle.left(90)

ninja_turtle.penup()
ninja_turtle.forward(90)
ninja_turtle.right(180)
ninja_turtle.pendown()

ninja_turtle.forward(180)
turtle.done()