# P4LAB1 A - Shapes

import turtle

my_turt = turtle.Turtle()


for x in range(4):
    my_turt.forward(50)
    my_turt.right(90)


my_turt.penup()
my_turt.forward(200)
my_turt.pendown()

for y in range(3):
    my_turt.forward(50)
    my_turt.right(120)






turtle.done()